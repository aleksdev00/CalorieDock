# CalorieDock Landing Page Design Package

Open `CalorieDock_Landing_Desktop_Mockup.html` for the framed 1440px presentation and `CalorieDock_Landing_Mobile_Mockup.html` for the framed 390px presentation.

`CalorieDock_Landing_Page_Mockup.html` is the responsive master mockup. It can be resized freely and is the visual source of truth.

`CalorieDock_Landing_Page_Specification.md` contains the implementation-ready layout, content, responsive, accessibility, SEO, route and acceptance requirements.


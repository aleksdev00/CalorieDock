# CalorieDock Landing Page — Implementation Specification

Version: 1.0  
Target: Next.js App Router, TypeScript, Tailwind CSS v4, shadcn/ui  
Primary route: `/`  
Authentication routes: `/login`, `/register`

## 1. Design intent

The landing page must look like the public face of the existing CalorieDock application—not a separate brand. It retains the product’s monochrome shadcn visual system, rounded cards, subtle borders, strong numeric hierarchy, restrained shadows and plain-language tone. The marketing layer adds larger typography, more whitespace, dashboard compositions and clearer conversion hierarchy.

Brand attributes: modern, premium, clean, professional, motivating and reliable.

Core promise: **Nutrition tracking that keeps the important things clear.**

The page sells the implemented MVP only: calories and macros, meals, food search, hydration, weight history, daily summaries and account/profile settings. AI, coaching, community, achievements, barcode scanning and unsupported numeric goals must not be presented as live features.

## 2. Page structure

| Order | Section | Purpose | Primary content |
|---:|---|---|---|
| 1 | Header | Brand recognition and conversion | Logo, Features, How it works, Dashboard, Sign in, Start tracking |
| 2 | Hero | State the value and show the product | Eyebrow, H1, supporting copy, two CTAs, trust notes, dashboard preview |
| 3 | Product proof | Show breadth without inflated claims | Calories, macros, hydration and weight metric cards |
| 4 | Feature grid | Explain the implemented product | Meal logging, food search, daily summary, water, weight, private account |
| 5 | Product spotlight | Make the portfolio work visible | Large dashboard composition with supporting callouts |
| 6 | How it works | Reduce perceived effort | Create account, log food and habits, review the day |
| 7 | Audience | Clarify who it helps | Lose weight, build muscle, eat with more awareness |
| 8 | Final CTA | Convert | “Your nutrition. Clear, organized, yours.” plus Register and Sign in |
| 9 | Footer | Utility and credibility | Product links, legal routes, copyright |

## 3. Responsive frames

### Desktop

- Design width: 1440px.
- Content max-width: 1200px (`max-w-7xl` may be retained where already standard).
- Horizontal page padding: 32px at `lg`, 24px at `sm`.
- Header height: 72px; sticky with `bg-background/90`, backdrop blur and bottom border.
- Hero: two columns, approximately 44% copy / 56% product preview.
- Hero top/bottom spacing: 104px / 96px.
- H1 maximum width: 650px; two or three lines at 1440px.
- Feature grid: three columns.
- Product spotlight: 40% supporting copy / 60% dashboard composition.
- How-it-works: three equal steps.

### Mobile

- Design width: 390px; support 320px upward.
- Horizontal padding: 20px.
- Header height: 64px. Hide anchor navigation; retain Sign in and compact primary CTA or menu.
- Hero becomes one column, copy first and preview second.
- H1 uses 42–46px with approximately 0.98 line-height; never smaller than 38px at 320px.
- CTA buttons stack and become full-width below 390px.
- Dashboard preview is intentionally simplified; never scale the entire desktop UI until text is unreadable.
- Metric and feature grids become one column. Two compact metric cards may share a row only at 375px and above.
- Section spacing: 72–88px.
- All interactive targets: minimum 44px.

## 4. Visual tokens

The implementation should reuse existing CSS variables from `src/app/globals.css`.

| Token | Existing value/use | Landing-page use |
|---|---|---|
| `--background` | White | Main canvas |
| `--foreground` | Near black | Headlines, primary UI |
| `--card` | White | Dashboard and feature surfaces |
| `--muted` | Light neutral | Section bands and preview canvas |
| `--muted-foreground` | Medium gray | Descriptions and metadata |
| `--primary` | Near black | Primary CTA and active states |
| `--border` | Soft gray | Cards, dividers and app chrome |
| `--radius` | 0.625rem | Base radius; use `rounded-xl` and `rounded-2xl` |

Marketing-only decorative treatment: soft neutral radial gradients using black at 4–7% opacity. Do not introduce a saturated brand color until the application design system is intentionally rebranded.

## 5. Typography

- Use the project’s existing sans-serif stack for exact visual continuity.
- Hero display: `text-5xl md:text-6xl lg:text-7xl`, bold, tight tracking.
- Section headings: `text-3xl md:text-5xl`, bold, tight tracking.
- Card headings: `text-lg` or `text-xl`, semibold.
- Body lead: `text-lg md:text-xl`, muted foreground, max 60 characters per line.
- Labels: `text-xs` to `text-sm`, medium/semibold.
- Numeric displays: bold, tabular numerals where available.

## 6. Header behavior

- Logo text: `CalorieDock`, linking to `/`.
- Desktop anchors: `#features`, `#how-it-works`, `#dashboard`.
- `Sign in` links to `/login` using a ghost/outline treatment.
- `Start tracking` links to `/register` using the primary button.
- Sticky header gains a subtle shadow only after scrolling.
- Anchor scrolling respects reduced-motion preferences.

## 7. Hero specification

Eyebrow: `A clearer way to track nutrition`

H1: `Nutrition tracking that keeps the important things clear.`

Supporting copy: `Log meals, understand your macros, track water and weight, and review every day from one focused dashboard.`

Primary CTA: `Start tracking free` → `/register`  
Secondary CTA: `See how it works` → `#how-it-works`

Trust row:

- Free to start
- Your data stays private
- Built for everyday tracking

The dashboard preview uses representative demo data only and must be labeled visually as a product preview. Suggested data: 1,847 kcal, 142 g protein, 196 g carbohydrates, 61 g fat, 2.1 L water, 92.4 kg latest weight.

## 8. Component inventory

Create a public marketing feature boundary such as:

```text
src/features/landing/
  components/
    LandingHeader.tsx
    HeroSection.tsx
    DashboardPreview.tsx
    MetricsStrip.tsx
    FeatureGrid.tsx
    ProductSpotlight.tsx
    HowItWorks.tsx
    AudienceSection.tsx
    FinalCta.tsx
    LandingFooter.tsx
  data/
    landing-content.ts
  index.ts
```

Prefer existing `Button`, `Card` and typography primitives. Keep marketing copy/data outside large JSX trees where practical. Landing components must not import authenticated services or user data.

## 9. Interaction and motion

- Buttons: existing shadcn states; 150–200ms color/transform transition.
- Cards: no constant floating animation. Optional hover lift of 2px on pointer devices.
- Dashboard preview: optional staggered entrance of 40–70ms per group, once on first view.
- Anchor navigation: smooth scroll only when `prefers-reduced-motion` permits.
- All information remains visible and understandable without motion.

## 10. Accessibility

- Exactly one H1.
- Semantic landmarks: header, main, section, footer and nav.
- Each section heading is referenced with `aria-labelledby`.
- Decorative icons use `aria-hidden="true"`.
- Dashboard preview is either fully semantic or a single figure with an explanatory caption.
- Visible focus rings use the existing `--ring` token.
- Text and controls meet WCAG AA contrast.
- Never communicate macro categories using color alone.
- Mobile menu must support keyboard operation, focus management and Escape dismissal.

## 11. SEO and metadata

Suggested metadata:

```ts
export const metadata: Metadata = {
  title: "CalorieDock | Simple calorie and nutrition tracking",
  description:
    "Track meals, calories, macros, water and weight with a clear daily nutrition dashboard.",
  alternates: { canonical: "/" },
  openGraph: {
    title: "CalorieDock | Nutrition tracking made clear",
    description:
      "One focused place for meals, macros, hydration, weight and daily summaries.",
    type: "website",
  },
}
```

Add a purpose-built 1200×630 Open Graph image after implementation. The public page should be server-rendered and must not redirect authenticated or unauthenticated visitors automatically. Authentication protection remains on private application routes.

## 12. Route changes

- Replace the login content currently rendered at `/` with the landing page.
- Keep login at `/login`.
- Keep registration at `/register`.
- After authentication, continue using the existing redirect logic to `/dashboard` or onboarding.
- The `CalorieDock` link inside `AuthShell` may continue linking to `/`, now correctly returning to the public landing page.

## 13. Performance requirements

- No heavy background video.
- Build the dashboard preview with HTML/CSS rather than a large screenshot where possible.
- Use SVG/Lucide icons already installed.
- Avoid client components except header/menu behavior and optional motion.
- Target Lighthouse: Performance ≥ 90, Accessibility ≥ 95, Best Practices ≥ 95, SEO ≥ 95 on production.
- Prevent layout shift by reserving preview and media dimensions.

## 14. Acceptance checklist

- `/` renders the public landing page without authentication.
- `/login` and `/register` remain functional.
- The landing page visually matches existing CalorieDock cards, controls and navigation.
- Only implemented MVP functionality is advertised.
- Desktop layout matches the 1440px mockup.
- Mobile layout matches the 390px mockup and works at 320px.
- Keyboard navigation, focus states and reduced motion are verified.
- Metadata, canonical URL and social metadata are present.
- `npm run lint` passes.
- Type checking passes using the repository’s defined script or `npx tsc --noEmit`.
- Production build passes with correctly configured environment variables.

